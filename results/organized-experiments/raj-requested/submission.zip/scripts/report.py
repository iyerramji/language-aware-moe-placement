from common import *
import subprocess,platform,zipfile

def read(folder):
 with (OUT/folder/'table.csv').open() as f:return list(csv.DictReader(f))
def fnum(x,k):return float(x[k])
def pick(rows,**kw):return next(x for x in rows if all(str(x[k])==str(v) for k,v in kw.items()))
def main():
 A=read('A');B=read('B');C=read('C');D=read('D');eight=(OUT/'B8/NOTES.md').exists()
 if eight:
  B+=read('B8');save_table(OUT/'B',B)
  details=json.loads((OUT/'B/solver-details.json').read_text());details8=json.loads((OUT/'B8/solver-details.json').read_text());(OUT/'B/solver-details-8gpu.json').write_text(json.dumps(details8,indent=2)+'\n')
 p,q,langs,m=data();s=json.loads((ROOT/'results/summary.json').read_text())
 setup='''# Setup reproduction — completed locally

1. A home GPU is the simulated origin assigned to a language’s requests.
2. Local share is the fraction of selected expert hits that can be served on that origin GPU.
3. Replicas are additional copies of existing logical experts on other GPUs, not new experts or changed router choices.
4. Imbalance is the busiest GPU’s expert-hit load divided by the average, reported here as a mean across layers and also a worst-layer value.
5. The first half of the supplied text fits the plan and the second half evaluates it; grouping, expert placement and copy selection must not use the evaluation half.

Reproduced four-GPU aware local share **0.3442** (target0.344) and home-conditioned baseline **0.2569** (target0.257), both within0.001.
'''
 (OUT/'SETUP.md').write_text(setup)
 # Update B interpretation and heuristic comparison using executed tables.
 notes=['# B: balance-aware placement',f'Executed four-GPU'+(' and eight-GPU' if eight else '')+' CPU simulations. Cap constrains fit-half PRIMARY expert load before replicas, not held-out final load. Each GPU holds exactly E/G primaries. Integer-program proof flags and timings are recorded per layer; greedy uses heavy-first placement followed by feasible pair swaps. No request latency measured.']
 for g in ([4,8] if eight else [4]):
  for cap in ['1.1','1.25','1.5','2.0','None']:
   z=pick(B,gpus=g,cap=cap,R=2,method='integer_program');gre=pick(B,gpus=g,cap=cap,R=2,method='greedy');gap=100*(fnum(z,'fit_objective')-fnum(gre,'fit_objective'))
   notes.append(f"- G={g}, cap={cap}, R=2: IP traffic cut {fnum(z,'traffic_cut_pct'):.3f}%, mean imbalance {fnum(z,'imbalance_mean'):.3f}; optimal {z['optimal_layers']}/48 layers; IP/greedy time {fnum(z,'solve_seconds'):.2f}/{fnum(gre,'solve_seconds'):.2f}s; greedy fit-local-share gap {gap:.3f} percentage points.")
 notes.append('For four GPUs and R2, cap1.1 is a useful conservative candidate:32.014% traffic cut at1.261 mean held-out imbalance, versus33.046% and1.987 without cap. This is an exploratory trade-off recommendation, not a predeclared winner or a latency guarantee. The greedy cap1.1 alternative gives31.061% at1.129 mean imbalance. More permissive caps are not guaranteed to improve held-out traffic: the fit objective optimizes primary locality before adding copies, and the data halves differ.')
 (OUT/'B/NOTES.md').write_text('\n\n'.join(notes)+'\n')
 # Uniform schema comparison table of selected four-GPU R2 plans.
 selected=[]
 for policy in ['blind','aware_blind_copies','aware']:
  x=pick(A,gpus=4,R=2,policy=policy);selected.append((policy,x))
 selected += [('aware cap1.1 IP',pick(B,gpus=4,R=2,cap='1.1',method='integer_program')),('aware cap1.1 greedy',pick(B,gpus=4,R=2,cap='1.1',method='greedy'))]
 lines=['# Local ablation findings — 9 November 2026','**Executed on this Mac using CPU only. No model weights, training, cloud resources or GPU benchmarks were used.**', '## What was run','Setup and A–D from the mentor repository. A/C:4and8 simulated GPUs. B:'+('4and8' if eight else '4')+' simulated GPUs. D:4 simulated GPUs, six fit mixtures × six served mixtures × two replica budgets. Source is the supplied Qwen3-30B-A3B/Wikipedia count file only: these runs do not reproduce the newer Sarvam, FLORES or Hinglish results in Raj’s email.', '## Main findings','1. **The baseline reproduces.** Four-GPU aware locality0.3442 and baseline0.2569 meet the supplied tolerance.','2. **Layout and request homing explain most of A’s language-aware advantage.** At R2/four GPUs the fully-aware plan gains9.975 percentage points of traffic reduction over blind; language-specific copy choice contributes only0.317 points of that.','3. **Balance-aware placement preserves most savings.** At R2/four GPUs, cap1.1 IP gives32.014% reduction versus33.046% for unconstrained aware placement, while mean layer imbalance falls from1.987 to1.261.','4. **Allocate copies by traffic benefit, not language specificity alone.** Greedy gain gives34.291% reduction on four GPUs,1.244 points over uniform, and33.004% on eight GPUs,1.454 points over uniform. Concentrating the budget in the12most specific layers performs worse than uniform on both GPU counts.','5. **Indic-only gains remain in this simulation.** Matched Indic-only R2 gives36.207% reduction versus25.104% for blind:11.103percentage points advantage. This is not evidence that Indic languages are highly distinct, nor does it isolate language labels from request homing/layout.','6. **Traffic shifts are a serious weakness.** Worst of the tested R2 mixtures loses51.555percentage points relative to a matched-fit plan. This is a static mixture mismatch result, not a dynamic adaptation or migration experiment.','## Equal traffic, four GPUs, two extra experts per GPU per layer','All percentages below use a language-blind, no-copy default with local share1/G as the common reference. This differs from the home-conditioned default reported by analyze.py. A percentage-point advantage is a difference of traffic-reduction percentages, not a relative percentage improvement.','| Plan | Local expert hits (%) | Remote-hit reduction (%) | Mean layer imbalance |','|---|---:|---:|---:|']
 for name,x in selected:lines.append(f"| {name} | {100*fnum(x,'local_share'):.2f} | {fnum(x,'traffic_cut_pct'):.2f} | {fnum(x,'imbalance_mean'):.3f} |")
 lines+=['## What surprised us / questions for Raj','- Removing English did not remove the simulated advantage. Check whether home assignment and the particular grouping constraints account for this, rather than interpreting it immediately as strong Indic language separation.','- A strict fit-load cap preserved nearly all four-GPU traffic savings after replicas. Consider replica-adjusted load directly in a future planner; the requested cap currently constrains primaries only.','- The most language-specific layers are not automatically where memory buys the most traffic reduction. Fit-half marginal gains are the better objective in C.','- A layout optimal for primary locality may not be optimal after copies, and an optimal fit solution need not beat a heuristic on held-out data.','## Evidence and limits','Traffic is a remote expert-hit proxy calculated from marginal counts. It is not measured network bytes, all-to-all time or p99 latency. Counts do not retain per-token expert co-selection, so token-transfer deduplication and co-selection graph objectives cannot be reconstructed exactly. Equal expert sizes, GPU compute speeds and uniform per-layer averaging are assumed. GPU/PCIe topology, scheduling, attention/KV pressure and replica migration costs are absent. The 300-candidate grouping search is seeded but heuristic; IP optimality applies only to fixed groups, specified capacity constraints and the primary-locality objective.','No per-sentence raw observations are available here for bootstrap uncertainty. No new claims about Sarvam, code-mixed input, padding, licensing or model quality are established by this analysis. D uses served-mixture-aware blind copies as a strong reference, and includes zero-weight English in the group search. Heavy traffic concentrates compute; locality alone is not throughput.','## Files','- [Setup explanation](SETUP.md)','- [A table](A/table.csv) · [A notes](A/NOTES.md)','- [B table](B/table.csv) · [B notes](B/NOTES.md)','- [C table](C/table.csv) · [C notes](C/NOTES.md)','- [D table](D/table.csv) · [D notes](D/NOTES.md)','- [Validation](validation.txt) · [Run manifest](manifest.json)','## Figures','![A: replication frontier](A/frontier.png)','![B: balance frontier](B/frontier.png)','![C: layer allocations](C/per_layer.png)','![D: R2 traffic mixes](D/fit_by_serve_R2.png)','![D: R4 traffic mixes](D/fit_by_serve_R4.png)']
 (OUT/'FINDINGS.md').write_text('\n\n'.join(lines)+'\n')
 manifest={'date':'2026-11-09','repository':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'platform':platform.platform(),'python':sys.version,'seed':0,'source_file':'results/routing_qwen3_30b_a3b.npz','source_sha256':hashlib.sha256((ROOT/'results/routing_qwen3_30b_a3b.npz').read_bytes()).hexdigest(),'baseline':s['ep'],'execution':'CPU simulation only; no GPU/cloud/training','tables_rows':{k:len(read(k)) for k in ['A','B','C','D']},'artifacts':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.rglob('*') if p.is_file() and p.name not in ['manifest.json','submission.zip']}}
 (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 (OUT/'environment.txt').write_text(subprocess.check_output([sys.executable,'-m','pip','freeze'],text=True))
 with zipfile.ZipFile(OUT/'submission.zip','w',zipfile.ZIP_DEFLATED) as z:
  for f in OUT.rglob('*'):
   if f.is_file() and f.name!='submission.zip':z.write(f,str(f.relative_to(OUT)))
  for f in (ROOT/'ablations').glob('*.py'):z.write(f,'scripts/'+f.name)
 print('Report and submission archive built; eightGPU_B=',eight)
if __name__=='__main__':main()
